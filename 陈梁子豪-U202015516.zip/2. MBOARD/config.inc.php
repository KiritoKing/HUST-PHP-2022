<?php
//数据库的地址
const DB_ADDRESS = "localhost";
//数据库用户名
const ACCOUNT_NAME = "root";
//数据库用户名对应的密码
const PASSWORD = "";
//数据库的名字
const DB_NAME = "gbook";
//数据库表的名字
const TABLE_NAME = "simple_mb";
//数据库字段的名字
const FIELD_NAME = "content";
?>